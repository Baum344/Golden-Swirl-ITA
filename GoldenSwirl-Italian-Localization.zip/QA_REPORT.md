# Report di controllo qualità

Controllo eseguito su tutte le **4.086 entry** (19 tabelle) confrontando inglese e italiano.

## 1. Integrità tecnica

Confronto automatico di:

- token `{...}` (anche annidati, es. `{cards:plural:{keyword.card}...}`);
- placeholder `%s`, `%d`, `%f`;
- tag TextMeshPro/custom `<wave>`, `<shake>`, `<wiggle>`, `<color=...>`, `</color>`, `<sprite ...>`, `<size=...>`, `<rewiredElement ...>`;
- escape `\n`, `\r`, `\t`.

Risultato: **1 mismatch su 4.086**, motivato (vedi punto 2). Tutte le altre stringhe hanno set di token identico all'originale. Nessuna chiave modificata, nessuna entry mancante, stessi `id`.

## 2. Caso `{Color:choose(...)}`

Stringa:

```
EN: ... {Color:choose(empty):|\nCurrent Battle Will: {Color}}
IT: ... {Color:choose(empty):|\nVolontà di Battaglia attuale: {Color}}
```

Nel `ChooseFormatter` di SmartFormat la sintassi è `{valore:choose(opzioni):risultati}`: `empty` è l'opzione, mentre `\nCurrent Battle Will: {Color}` è un **risultato letterale renderizzato** quando il valore non è vuoto. Si tratta quindi di **testo mostrato al giocatore**, non di un parametro tecnico. Gli altri due usi di `choose` nel gioco (SkillTree) confermano la convenzione. La traduzione è corretta.

## 3. Residui inglesi

Ricerca di function words inglesi nel testo italiano (dopo rimozione di token/markup): **0 residui reali**.

I valori rimasti identici EN=IT (~260) rientrano in:

- nomi propri (Novelia, Rayden, Evanna, Zerena, Lorenzo, Kthura'Dian, …);
- acronimi (SP, PS, OK, VSync, Steam, QQ, UI, SFX…);
- URL e stringhe tecniche;
- placeholder/dev (`Act1_Boss`, `throwing_shield`, `Slash_Grey`, `Kaboom …`, `[del]`);
- termini gameplay volutamente invariati (Combo, Focus, Gameplay).

## 4. Coerenza terminologica

Verifica automatica (testo semplice, token esclusi, "leftover" inglese = 0) per: Block, Strength, Toughness, Slow, Haste, Fatigue, Vulnerable, Evasion, Regen, Thorns, Stun, Exhaust, Exert, Storm, Chain, Potion, Synergy, Relic, Charm, Health, Will, SP, HP. Nessuna traduzione divergente senza motivo.

## 5. Qualità dell'italiano

- Revisione delle stringhe UI principali (menu, opzioni, pulsanti, tooltip, messaggi) e delle narrazioni Event.
- Scansione igienica: nessun carattere non latino, nessuna doppia spaziatura, punteggiatura coerente.
- I testi troppo lunghi sono evitati dove possibile; le stringhe che crescono (es. `Buff` → `Potenziamento`) restano leggibili.

## 6. Termini di lore

Tutti verificati e coerenti con il contesto (titoli, luoghi, oggetti, eventi): Nameless, Dawn Maiden, Hand of Cinders, Aeon of a Thousand Ruins, Star Silk, Great Dreamer, Swirl Breaching, Golden God, Golden Power, Golden Path, Silver Beast, Twilight Rebels, Nemici dei Great Dreamers. Vedi `GLOSSARY.md`.

## 7. Stringhe dubbie (stilistiche, non errori)

- `Focalizzate su tiri abilità e trappole` (`YellowCard.desc`): "tiri abilità" un po' rigido.
- Spazi prima di `!`/`:` che ricalcano l'inglese (`Nuova Carta !`, `Tempo d'Azione : {actionTime}`).
- `Buff` → `Potenziamento` (label): corretto ma lungo; mantenuto per coerenza.

## 8. Validazione finale

- Entry totali: **4.086** (invariate).
- Mismatch tecnici: **0** non motivati.
- Bundle italiani: identità interne univoche (CAB e `AssetBundle.m_Name` distinti dagli originali).
- Catalogo: invariato rispetto alla patch funzionante.
- Avvio: il gioco raggiunge il menu principale senza errori Addressables.
