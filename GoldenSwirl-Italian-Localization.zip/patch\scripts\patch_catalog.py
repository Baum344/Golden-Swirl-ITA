import json, base64, struct, os, hashlib, uuid
import UnityPy

BASE=r'C:\Users\baum3\AppData\Local\Temp\opencode\gs'
AA=r'C:\Users\baum3\Desktop\Golden.Swirl\game\GoldenSwirl_Data\StreamingAssets\aa'
BUILD=os.path.join(BASE,'build')
CAT=os.path.join(AA,'catalog.json')
cat=json.load(open(CAT,encoding='utf-8'))

def ri(b,o): return struct.unpack_from('<i',b,o)[0]
def read_obj(kd,di):
    t=kd[di];di+=1
    if t==0:
        ln=ri(kd,di);return kd[di+4:di+4+ln].decode('ascii')
    if t==1:
        ln=ri(kd,di);return kd[di+4:di+4+ln].decode('utf-16-le')
    if t==2:return struct.unpack_from('<H',kd,di)[0]
    if t==3:return struct.unpack_from('<I',kd,di)[0]
    if t==4:return ri(kd,di)
    if t==5:
        ln=kd[di];return kd[di+1:di+1+ln].decode('ascii')
    if t==6:
        ln=kd[di];return('TYPE',kd[di+1:di+1+ln].hex())
    raise ValueError(t)

kd=base64.b64decode(cat['m_KeyDataString'])
bd=base64.b64decode(cat['m_BucketDataString'])
ed=base64.b64decode(cat['m_EntryDataString'])
xd=base64.b64decode(cat['m_ExtraDataString'])
internal=list(cat['m_InternalIds'])
providers=list(cat['m_ProviderIds'])
rtypes=list(cat['m_resourceTypes'])

bc=ri(bd,0); buckets=[]; bi=4
for i in range(bc):
    off=ri(bd,bi);bi+=4;ec=ri(bd,bi);bi+=4
    es=[ri(bd,bi+4*j) for j in range(ec)];bi+=4*ec
    buckets.append([off,es])
keys=[read_obj(kd,o) for o,e in buckets]
ecount=ri(ed,0); entries=[list(struct.unpack_from('<7i',ed,4+i*28)) for i in range(ecount)]
print('parsed keys',len(keys),'entries',ecount)

def rt_idx(cls):
    for i,t in enumerate(rtypes):
        if t['m_ClassName']==cls: return i
    raise KeyError(cls)
RT_BUNDLE=rt_idx('UnityEngine.ResourceManagement.ResourceProviders.IAssetBundleResource')
RT_STRING=rt_idx('UnityEngine.Localization.Tables.StringTable')
RT_ASSET=rt_idx('UnityEngine.Localization.Tables.AssetTable')
RT_LOCALE=rt_idx('UnityEngine.Localization.Locale')
PROV_BUNDLE=providers.index('UnityEngine.ResourceManagement.ResourceProviders.AssetBundleProvider')
PROV_ASSET=providers.index('UnityEngine.ResourceManagement.ResourceProviders.BundledAssetProvider')

path_index={}
for i,p in enumerate(internal):
    if p.endswith('.asset'): path_index[p]=i
def idx_for_path(p):
    if p not in path_index: raise KeyError(p)
    return path_index[p]

collections=['Buff Table','Event Table','Card Table','IntroSubtitleTable','RelicTable','MessageBoxTable',
'Character Table','Modifier Table','UnlockContentTable','AscensionEffectTable','Shop Table','SwirlEffectTable',
'CommonStringTable','ZoneBuffEffectTable','CardTagTable','SkillTreeTable','Popup','EquipmentTable','Currency Table']
col_path={
'AscensionEffectTable':'Assets/Settings/Language/StringTable/Ascension/AscensionEffectTable_en.asset',
'Buff Table':'Assets/Settings/Language/StringTable/Buff/Buff Table_en.asset',
'Card Table':'Assets/Settings/Language/StringTable/Card/Card Table_en.asset',
'CardTagTable':'Assets/Settings/Language/StringTable/CardTag/CardTagTable_en.asset',
'Character Table':'Assets/Settings/Language/StringTable/Character/Character Table_en.asset',
'CommonStringTable':'Assets/Settings/Language/StringTable/Common/CommonStringTable_en.asset',
'UnlockContentTable':'Assets/Settings/Language/StringTable/ContentUnlock/UnlockContentTable_en.asset',
'Currency Table':'Assets/Settings/Language/StringTable/Currency/Currency Table_en.asset',
'EquipmentTable':'Assets/Settings/Language/StringTable/EquipmentTable/EquipmentTable_en.asset',
'Event Table':'Assets/Settings/Language/StringTable/Event/Event Table_en.asset',
'IntroSubtitleTable':'Assets/Settings/Language/StringTable/IntroSubtitle/IntroSubtitleTable_en.asset',
'MessageBoxTable':'Assets/Settings/Language/StringTable/MessageBox/MessageBoxTable_en.asset',
'Modifier Table':'Assets/Settings/Language/StringTable/Modifier/Modifier Table_en.asset',
'Popup':'Assets/Settings/Language/StringTable/Popup/Popup_en.asset',
'RelicTable':'Assets/Settings/Language/StringTable/Relic/RelicTable_en.asset',
'Shop Table':'Assets/Settings/Language/StringTable/Shop/Shop Table_en.asset',
'SkillTreeTable':'Assets/Settings/Language/StringTable/SkillTree/SkillTreeTable_en.asset',
'SwirlEffectTable':'Assets/Settings/Language/StringTable/SwirlEffect/SwirlEffectTable_en.asset',
'ZoneBuffEffectTable':'Assets/Settings/Language/StringTable/ZoneBuff/ZoneBuffEffectTable_en.asset'}
asset_table_path='Assets/Settings/Language/AssetTable/AssetTable_en.asset'
locale_path='Assets/Settings/Language/English (en).asset'

shared_ei=None
for i,e in enumerate(entries):
    if 'localization-assets-shared_assets_all.bundle' in internal[e[0]]:
        shared_ei=i;break
assert shared_ei is not None

len_i=keys.index('Locale-en'); len_entries=buckets[len_i][1]
nontable=[e for e in len_entries if rtypes[entries[e][6]]['m_ClassName'] not in ('UnityEngine.Localization.Tables.StringTable','UnityEngine.Localization.Tables.AssetTable')]
print('Locale-en nontable',len(nontable))

E=ecount; K=len(keys); new_internal=[]
def bundle_info(fname):
    p=os.path.join(BUILD,fname)
    h=hashlib.md5(open(p,'rb').read()).hexdigest()
    size=os.path.getsize(p)
    env=UnityPy.load(p)
    mname=None
    for obj in env.objects:
        if obj.type.name=='AssetBundle': mname=obj.read().m_Name; break
    bn=mname[:-7] if (mname and mname.endswith('.bundle')) else mname
    internal_path='{UnityEngine.AddressableAssets.Addressables.RuntimePath}\\StandaloneWindows64\\'+fname
    new_internal.append(internal_path)
    return h,size,bn

st_name='localization-string-tables-italian(it)_assets_all.bundle'
at_name='localization-asset-tables-italian(it)_assets_all.bundle'
lo_name='localization-locales-italian(it)_assets_all.bundle'
st_h,st_sz,st_bn=bundle_info(st_name)
at_h,at_sz,at_bn=bundle_info(at_name)
lo_h,lo_sz,lo_bn=bundle_info(lo_name)
IDX_ST=len(internal)+0; IDX_AT=len(internal)+1; IDX_LO=len(internal)+2

E_ST=E; E_AT=E+1; E_LO=E+2
E_TAB={col:E+3+i for i,col in enumerate(collections)}
E_ASSETTABLE=E+22; E_LOCALE=E+23

K_ST=K; K_AT=K+1; K_LO=K+2; K_DEPST=K+3; K_DEPAT=K+4; K_LOCALEIT=K+5
K_ADDR={col:K+6+i for i,col in enumerate(collections)}
K_GUID={col:K+25+i for i,col in enumerate(collections)}
K_ASSETTABLE=K+44; K_ASSETTABLE_GUID=K+45; K_LOCALE=K+46; K_LOCALE_GUID=K+47
NEW_KEYS=48

st_key=f'localization-string-tables-italian(it)_assets_all_{st_h}.bundle'
at_key=f'localization-asset-tables-italian(it)_assets_all_{at_h}.bundle'
lo_key=f'localization-locales-italian(it)_assets_all_{lo_h}.bundle'

ASM='Unity.ResourceManager, Version=0.0.0.0, Culture=neutral, PublicKeyToken=null'
CLS='UnityEngine.ResourceManagement.ResourceProviders.AssetBundleRequestOptions'
def json_obj(asm,cls,js):
    a=asm.encode('ascii');c=cls.encode('ascii');j=js.encode('utf-16-le')
    return bytes([7,len(a)])+a+bytes([len(c)])+c+struct.pack('<i',len(j))+j
def extra_text(h,size,name):
    return json.dumps({"m_Hash":h,"m_Crc":0,"m_Timeout":0,"m_ChunkedTransfer":False,"m_RedirectLimit":-1,
        "m_RetryCount":0,"m_BundleName":name,"m_AssetLoadMode":0,"m_BundleSize":size,
        "m_UseCrcForCachedBundles":False,"m_UseUWRForLocalBundles":False,"m_ClearOtherCachedVersionsWhenLoaded":False},
        separators=(',',':'))

def add_entry(iid,prov,dep,depHash,data,primary,rt):
    entries.append([iid,prov,dep,depHash,data,primary,rt])
DATA_ST=len(xd); xd_add=json_obj(ASM,CLS,extra_text(st_h,st_sz,st_bn))
DATA_AT=DATA_ST+len(xd_add); xd_add2=json_obj(ASM,CLS,extra_text(at_h,at_sz,at_bn))
DATA_LO=DATA_AT+len(xd_add2); xd_add3=json_obj(ASM,CLS,extra_text(lo_h,lo_sz,lo_bn))
add_entry(IDX_ST,PROV_BUNDLE,-1,0,DATA_ST,K_ST,RT_BUNDLE)
add_entry(IDX_AT,PROV_BUNDLE,-1,0,DATA_AT,K_AT,RT_BUNDLE)
add_entry(IDX_LO,PROV_BUNDLE,-1,0,DATA_LO,K_LO,RT_BUNDLE)
for col in collections:
    add_entry(idx_for_path(col_path[col]),PROV_ASSET,K_DEPST,0,-1,K_ADDR[col],RT_STRING)
add_entry(idx_for_path(asset_table_path),PROV_ASSET,K_DEPAT,0,-1,K_ASSETTABLE,RT_ASSET)
add_entry(idx_for_path(locale_path),PROV_ASSET,K_LO,0,-1,K_LOCALE,RT_LOCALE)

new_keys=[st_key,at_key,lo_key,'900000001','900000002','Locale-it']
for col in collections: new_keys.append(col+'_it')
for col in collections: new_keys.append(uuid.uuid4().hex)
new_keys+=['AssetTable_it',uuid.uuid4().hex,'Italian (it)',uuid.uuid4().hex]
assert len(new_keys)==NEW_KEYS

def bucket_for(o):
    if o==0: return [E_ST]
    if o==1: return [E_AT]
    if o==2: return [E_LO]
    if o==3: return [E_ST,shared_ei]
    if o==4: return [E_AT,shared_ei]
    if o==5: return nontable+[E_TAB[c] for c in collections]+[E_ASSETTABLE]
    if 6<=o<25: return [E_TAB[collections[o-6]]]
    if 25<=o<44: return [E_TAB[collections[o-25]]]
    if o in (44,45): return [E_ASSETTABLE]
    if o in (46,47): return [E_LOCALE]
    raise ValueError(o)
new_buckets=[bucket_for(i) for i in range(NEW_KEYS)]
buckets[keys.index('Locale')][1].append(E_LOCALE)

out_kd=bytearray(); out_kd+=struct.pack('<i',K+NEW_KEYS); out_kd+=kd[4:]
key_offsets=[]
for s in new_keys:
    key_offsets.append(len(out_kd)); b=s.encode('ascii'); out_kd+=b'\x00'+struct.pack('<i',len(b))+b
out_bd=bytearray(); out_bd+=struct.pack('<i',len(buckets)+len(new_buckets))
for off,es in buckets:
    out_bd+=struct.pack('<i',off)+struct.pack('<i',len(es))+b''.join(struct.pack('<i',e) for e in es)
for i,es in enumerate(new_buckets):
    out_bd+=struct.pack('<i',key_offsets[i])+struct.pack('<i',len(es))+b''.join(struct.pack('<i',e) for e in es)
out_ed=bytearray(); out_ed+=struct.pack('<i',len(entries))
for e in entries: out_ed+=struct.pack('<7i',*e)
out_xd=bytearray(); out_xd+=xd; out_xd+=xd_add; out_xd+=xd_add2; out_xd+=xd_add3

cat['m_InternalIds']=internal+new_internal
cat['m_KeyDataString']=base64.b64encode(bytes(out_kd)).decode()
cat['m_BucketDataString']=base64.b64encode(bytes(out_bd)).decode()
cat['m_EntryDataString']=base64.b64encode(bytes(out_ed)).decode()
cat['m_ExtraDataString']=base64.b64encode(bytes(out_xd)).decode()
out=os.path.join(BASE,'catalog_it.json')
json.dump(cat,open(out,'w',encoding='utf-8'),ensure_ascii=False)
print('wrote',out,'keys',len(buckets)+len(new_buckets),'entries',len(entries))
print('bundle names',st_bn,at_bn,lo_bn)
