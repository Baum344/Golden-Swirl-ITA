# Nota legale

Questa è una **traduzione non ufficiale creata da fan** per *Golden Swirl*.

- *Golden Swirl*, i suoi testi originali, gli asset, il codice e i marchi sono di proprietà di **Snako Production Limited**.
- Questo pacchetto **non contiene il gioco** e non è affiliato, approvato o sponsorizzato da Snako Production.
- I file in `patch/overlay/` sono copie modificate dei file del gioco (tabelle di localizzazione, catalogo Addressables e `Assembly-CSharp.dll`) rese disponibili **esclusivamente** per applicare la traduzione alla propria copia personale del gioco.
- La traduzione (il lavoro di adattamento dei testi) è distribuita con licenza **Creative Commons Attribution-NonCommercial-ShareAlike 4.0** (CC BY-NC-SA 4.0), salvo diversa indicazione dell'autore.
- Se sei un rappresentante di Snako Production e desideri la rimozione di questo contenuto, apri una issue o contatta l'autore.

Nessun gioco, nessun asset grafico o audio originale viene ridistribuito oltre a quanto strettamente necessario per applicare la patch alla copia locale dell'utente.
