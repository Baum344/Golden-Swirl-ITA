<#
    apply-italian.ps1 - Installa la traduzione italiana di Golden Swirl.
    Uso:
        .\apply-italian.ps1 -GameDir "C:\percorso\a\Golden Swirl"
    Se -GameDir non e' specificato, usa la cartella padre di questo script
    (utile se il pacchetto e' stato copiato dentro la cartella del gioco).
#>
param(
    [string]$GameDir = ""
)

$ErrorActionPreference = "Stop"
$Overlay = Join-Path $PSScriptRoot "patch\overlay"

if (-not $GameDir) {
    $GameDir = Split-Path $PSScriptRoot -Parent
}
$DataDir = Join-Path $GameDir "GoldenSwirl_Data"

if (-not (Test-Path -LiteralPath $DataDir)) {
    Write-Error "Non trovo '$DataDir'. Usa -GameDir per indicare la cartella che contiene GoldenSwirl.exe e GoldenSwirl_Data."
}

$stamp = Get-Date -Format "yyyyMMdd-HHmmss"
$backup = Join-Path $GameDir "italian-backup-$stamp"
Write-Host "Backup dei file originali in: $backup"

$files = Get-ChildItem -LiteralPath $Overlay -Recurse -File
foreach ($f in $files) {
    $rel = $f.FullName.Substring($Overlay.Length).TrimStart('\')
    $dest = Join-Path $GameDir $rel
    $destDir = Split-Path $dest -Parent
    if (-not (Test-Path -LiteralPath $destDir)) { New-Item -ItemType Directory -Force -Path $destDir | Out-Null }
    if (Test-Path -LiteralPath $dest) {
        $bdir = Join-Path $backup (Split-Path $rel -Parent)
        if (-not (Test-Path -LiteralPath $bdir)) { New-Item -ItemType Directory -Force -Path $bdir | Out-Null }
        Copy-Item -LiteralPath $dest -Destination (Join-Path $backup $rel) -Force
    }
    Copy-Item -LiteralPath $f.FullName -Destination $dest -Force
    Write-Host "  installato: $rel"
}

Write-Host ""
Write-Host "Fatto. Avvia il gioco e in Opzioni > Lingua seleziona 'Italiano'." -ForegroundColor Green
Write-Host "Per ripristinare: copia indietro i file da '$backup'."
