import struct, shutil, os
P=r'C:\Users\baum3\Desktop\Golden.Swirl\game\GoldenSwirl_Data\Managed\Assembly-CSharp.dll'
OUT=r'C:\Users\baum3\AppData\Local\Temp\opencode\gs\Assembly-CSharp.it.dll'
B=bytearray(open(P,'rb').read())
def u16(o): return struct.unpack_from('<H',B,o)[0]
def u32(o): return struct.unpack_from('<I',B,o)[0]
def w32(o,v): struct.pack_into('<I',B,o,v)
def w16(o,v): struct.pack_into('<H',B,o,v)

e=u32(0x3C); nsec=u16(e+6); sizeopt=u16(e+20); opt=e+24
magic=u16(opt); ddir=opt+(96 if magic==0x10b else 112)
sec_off=opt+sizeopt
def sections():
    s=[]
    for i in range(nsec):
        o=sec_off+i*40
        name=B[o:o+8].rstrip(b'\x00').decode('latin1')
        s.append((name,o,u32(o+12),u32(o+8),u32(o+20),u32(o+16)))
    return s
secs=sections()
def rva2off(rva):
    for name,o,va,vs,rp,rs in secs:
        if va<=rva<va+max(vs,rs): return rp+(rva-va)
    return None
cli_rva=u32(ddir+14*8); co=rva2off(cli_rva)
md_rva=u32(co+8); md_size=u32(co+12); mo=rva2off(md_rva)
# parse metadata streams
ver_len=u32(mo+12); p=mo+16+ver_len+2
nstreams=u16(p); p+=2
streams={}
for i in range(nstreams):
    off=u32(p); size=u32(p+4); sh=p; p+=8
    n=''
    while B[p]!=0: n+=chr(B[p]); p+=1
    p+=1; p=(p+3)&~3
    streams[n]=(off,size,sh)
print('streams',{k:(hex(v[0]),hex(v[1])) for k,v in streams.items()})

# ---- disable debug directory (DataDirectory[6]) ----
w32(ddir+6*8,0); w32(ddir+6*8+4,0)

# ---- parse #US to find 'it' token ----
us_off,us_size,us_sh=streams['#US']
us_file=mo+us_off
def us_iter():
    i=us_file+1; end=us_file+us_size
    while i<end:
        b0=B[i]
        if b0==0: break
        if b0&0x80==0: ln=b0; hb=1
        elif b0&0xC0==0x80: ln=((b0&0x3F)<<8)|B[i+1]; hb=2
        else: ln=((b0&0x1F)<<24)|(B[i+1]<<16)|(B[i+2]<<8)|B[i+3]; hb=4
        data_start=i+hb
        raw=bytes(B[data_start:data_start+ln])
        yield (i-us_file, raw)
        i=data_start+ln+1
def mk_us(s):
    d=s.encode('utf-16-le')
    e=bytes([len(d)])+d+b'\x00'
    while len(e)%4: e+=b'\x00'
    return e
us_blob=mk_us('it')+mk_us('Italiano')
delta=len(us_blob)
it_tok=us_size
italic_off=us_size+len(mk_us('it'))
print('it token offset',hex(it_tok),'italiano offset',hex(italic_off),'delta',delta)
newstr=us_blob
meta_end=mo+md_size
# shift [us_file+us_size, meta_end) right by delta
B[us_file+us_size+delta:meta_end+delta]=B[us_file+us_size:meta_end]
B[us_file+us_size:us_file+us_size+delta]=newstr
# update #US size, #GUID/#Blob offsets, metadata size
w32(us_sh+4, us_size+delta)
for nm in ['#GUID','#Blob']:
    off,size,sh=streams[nm]; w32(sh, off+delta)
w32(co+12, md_size+delta)
print('new #US size',hex(us_size+delta),'italian tok',hex(0x70000000|italic_off))

# ---- locate .cctor and Init MethodDef rows ----
import dnfile
pe=dnfile.dnPE(P); md=pe.net.mdtables
md_off=md.MethodDef.file_offset
rowsize=md.MethodDef.row_size
def rva_field_off(rid): return md_off+(rid-1)*rowsize
cctor=None; init=None
for t in md.TypeDef:
    if str(t.TypeName)!='OptionsUIPanel': continue
    for mi in (t.MethodList or []):
        m=mi.row
        if str(m.Name)=='.cctor': cctor=m
        if str(m.Name)=='Init': init=m
print('cctor RID',hex(cctor.row_index if hasattr(cctor,'row_index') else 0), cctor.Rva)
# find RID via RVA match in MethodDef rows
cctor_rid=None; init_rid=None
for i,m in enumerate(md.MethodDef.rows):
    if m.Rva==cctor.Rva: cctor_rid=i+1
    if m.Rva==init.Rva: init_rid=i+1
print('cctor_rid',cctor_rid,'init_rid',init_rid,'init RVA',hex(init.Rva))
# body size of Init
def body_size(rva):
    o=rva2off(rva); b0=B[o]
    if (b0&3)==2: return 1+(b0>>2)
    flags=u16(o); hsize=(flags>>12)&0xF; return hsize*4+u32(o+4)
init_size=body_size(init.Rva)
cctor_off=rva2off(cctor.Rva); cctor_codesize=u32(cctor_off+4)
print('cctor off',hex(cctor_off),'codesize',cctor_codesize,'init rva',hex(init.Rva),'size',init_size)
# ---- relocate Init to slack ----
# place at RVA 0x482D00
init_new_rva=0x482D00
init_new_off=0x200+(init_new_rva-0x2000)
init_body=bytes(B[rva2off(init.Rva):rva2off(init.Rva)+init_size])
print('init body len',len(init_body),'target off',hex(init_new_off),'target rva',hex(init_new_rva))
meta_new_end=meta_end+delta
assert init_new_off>=meta_new_end, (hex(init_new_off),hex(meta_new_end))
assert init_new_off+len(init_body)<=0x481000
B[init_new_off:init_new_off+len(init_body)]=init_body
# update Init RVA
w32(rva_field_off(init_rid), init_new_rva)
# ---- rewrite .cctor body ----
cctor_code=bytes(B[cctor_off+12:cctor_off+12+cctor_codesize])
insert_idx=0xF9
assert cctor_code[insert_idx]==0x19, hex(cctor_code[insert_idx])
ins = bytes([0x7E])+struct.pack('<I',0x040024CD) \
    + bytes([0x72])+struct.pack('<I',0x70000000|italic_off) \
    + bytes([0x72])+struct.pack('<I',0x70000000|it_tok) \
    + bytes([0x6F])+struct.pack('<I',0x0A001E8F)
assert len(ins)==20
new_code=cctor_code[:insert_idx]+ins+cctor_code[insert_idx:]
# header
flags=u16(cctor_off); maxstack=u16(cctor_off+2); localsig=u32(cctor_off+8)
new_header=struct.pack('<HHI',flags,maxstack,len(new_code))+struct.pack('<I',localsig)
B[cctor_off:cctor_off+12+len(new_code)]=new_header+new_code
print('new cctor code size',len(new_code),'body end rva',hex(cctor.Rva+12+len(new_code)))
# ---- grow .text VirtualSize to cover relocated Init ----
for name,o,va,vs,rp,rs in secs:
    if name=='.text':
        need=init_new_rva+len(init_body)-va
        if need>vs:
            w32(o+8, (need+0xF)&~0xF)
            print('text VS ->',hex((need+0xF)&~0xF))
open(OUT,'wb').write(bytes(B))
print('wrote',OUT,os.path.getsize(OUT))
