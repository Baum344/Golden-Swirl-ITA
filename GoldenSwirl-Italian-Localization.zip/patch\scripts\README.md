# Strumenti per ricostruire la traduzione

Questi script sono gli strumenti usati per generare il pacchetto a partire dalla build del gioco. Servono solo se vuoi ricostruire/aggiornare la traduzione; per installarla basta `apply-italian.ps1`.

> Nota: gli script contengono percorsi assoluti usati durante lo sviluppo (cartella del gioco, cartella di lavoro temporanea). Adatta le costanti in testa a ogni file prima di eseguirli.

## `build_italian_bundles.py`

Costruisce i tre bundle italiani partendo dai bundle inglesi originali:

- `localization-string-tables-italian(it)_assets_all.bundle`
- `localization-asset-tables-italian(it)_assets_all.bundle`
- `localization-locales-italian(it)_assets_all.bundle`

per ogni stringa sostituisce la traduzione, imposta `m_LocaleId = "it"`, e assegna **identità interne univoche** (nome CAB e `AssetBundle.m_Name`) per evitare il conflitto "another AssetBundle with the same files is already loaded".

Input: `it_ordered.json` (traduzioni ordinate per tabella) e i bundle inglesi del gioco.
Richiede: `UnityPy`.

## `patch_catalog.py`

Aggiunge al `catalog.json` di Addressables, partendo dal catalogo **originale**:

- 3 bundle (internal id + description);
- 19 entry `StringTable` (`<Tabella>_it`) + 1 `AssetTable_it` + 1 `Locale` "Italian (it)";
- chiavi/indirizzi, GUID, label `Locale-it`, dependency set verso il bundle condiviso;
- aggiorna l'ExtraData (`AssetBundleRequestOptions`) con hash/dimensione/nome dei nuovi bundle.

Eseguito una sola volta sul catalogo originale (non rieseguirlo su un catalogo già patchato).

## `patch_assembly_csharp.py`

Patcha `Assembly-CSharp.dll` per aggiungere `"Italiano" → "it"` alla dizionario hardcoded `LanguageDic` di `Core.Panel.OptionsUIPanel::.cctor`:

1. aggiunge le stringhe utente `"it"` e `"Italiano"` al heap `#US` (e aggiorna `#US`, `#GUID`, `#Blob`, dimensione metadata);
2. inserisce 4 istruzioni IL nel `.cctor`;
3. trasloca il metodo `Init` nello slack di `.text` per fare spazio, aggiornando `MethodDef.Rva`;
4. disabilita la Debug Directory PE (inutilizzata).

Richiede: `dnfile` e `dncil`.

## `build_translation_tables.py`

Ricostruisce `it_final.json` / `it_ordered.json` a partire dal corpus inglese e dai file di traduzione, applicando le correzioni e la validazione dei token.

## Consiglio

Prima di rigenerare, fai sempre un backup della cartella del gioco: gli script sovrascrivono `catalog.json` e `Assembly-CSharp.dll`.
