# Glossario EN → IT

Terminologia usata in modo coerente in tutta la traduzione. I token (`{...}`, `<...>`) non vengono mai tradotti.

## Meccaniche di gioco

| English | Italiano |
|---|---|
| Block | Blocco |
| Strength | Forza |
| Toughness (Dexterity) | Robustezza |
| Slow | Lento / lentezza |
| Haste | Rapidità |
| Fatigue | Fatica |
| Vulnerable | Vulnerabile |
| Evasion | Evasione |
| Regen | Rigenerazione |
| Thorns | Spine |
| Stun | Stordimento |
| Exhaust | Esausto |
| Exert | Sforzo |
| Storm | Tempesta |
| Chain | Catena |
| Potion | Pozione |
| Synergy | Sinergia |
| Relic | Reliquia |
| Charm | Talismano |
| Health | Salute |
| Will / Will Icon | Volontà / Icona di Volontà |
| Battle Will | Volontà di Battaglia |
| Golden Will | Volontà Dorata |
| SP (Spirit Power) | SP (Potere Spirituale) |
| HP | PS |
| Gold | oro |
| Curse | Maledizione |
| Combo | Combo |
| Rage | Furia |
| Vigor | Vigore |
| Energized | Energizzato |
| Draw | Pesca |
| Discard | Scarta |
| Redraw | Rimescola / rimescolamento |
| Banish | Bandisci |
| Charm (card upgrade) | Incanta / Talismano |
| Charm Card | Carta Incantata |

## Termini di lore

| English | Italiano |
|---|---|
| Nameless One | Senza Nome |
| Dawn Maiden | Fanciulla dell'Alba |
| Hand of Cinders | Mano delle Ceneri |
| Aeon of a Thousand Ruins | Eone delle Mille Rovine |
| Star Silk | Seta Stellare |
| Great Dreamer(s) | Grande Sognatore / Grandi Sognatori |
| Swirl Breaching | Breccia del Vortice |
| The Swirl | Il Vortice |
| Golden God | Dio Dorato |
| Golden Power | Potere Dorato |
| Golden Path | Sentiero Dorato |
| Silver Beast | Bestia d'Argento |
| Twilight Rebels | Ribelli del Crepuscolo |
| Heart of Dread (Kthura'Dian) | Cuore del Terrore |
| Mother of Chaos (Elith'ryasa) | Madre del Caos |
| Eternal War Hymn (Maltha'helis) | Inno di Guerra Eterno |
| Devourer of Sense (Nath'thulas) | Divoratore del Senso |

## Luoghi / luoghi chiave

| English | Italiano |
|---|---|
| Silent Courtyard | Cortile Silenzioso |
| Awakening Altar | Altare del Risveglio |
| The Golden Tree | L'Albero Dorato |
| Fountain of Rebirth | Fontana della Rinascita |
| The Omniscient | L'Onnisciente |
| Illumi Ruins | Rovine di Illumi |
| The Golden Sanctum | Il Santuario Dorato |

## Uso delle maiuscole

Le keyword di gameplay che sono **nomi di meccaniche** mantengono l'iniziale maiuscola (Blocco, Forza, Reliquia, Talismano, Sinergia, Icona di Volontà). Gli aggettivi/stati comuni seguono l'uso normale.
