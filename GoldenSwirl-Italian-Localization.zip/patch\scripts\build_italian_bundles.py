import UnityPy, json, os, hashlib

BASE=r'C:\Users\baum3\AppData\Local\Temp\opencode\gs'
SW=r'C:\Users\baum3\Desktop\Golden.Swirl\game\GoldenSwirl_Data\StreamingAssets\aa\StandaloneWindows64'
OUT=os.path.join(BASE,'build')
os.makedirs(OUT, exist_ok=True)
it=json.load(open(os.path.join(BASE,'it_ordered.json'),encoding='utf-8'))
en=json.load(open(os.path.join(BASE,'corpus.json'),encoding='utf-8'))
assert set(it.keys())==set(en.keys())

def unique_names(env, kind):
    info={}
    for obj in env.objects:
        if obj.type.name=='AssetBundle':
            d=obj.read()
            old_m=d.m_Name
            d.m_Name=hashlib.md5((str(old_m)+'-it-'+kind).encode()).hexdigest()+'.bundle'
            obj.save_typetree(d)
            info['mname']=d.m_Name
            break
    old_cabs=list(env.file.files.keys())
    new_cabs=[]
    for old in old_cabs:
        new='CAB-'+hashlib.md5((old+'-it-'+kind).encode()).hexdigest()
        sf=env.file.files[old]; sf.name=new
        env.file.files[new]=env.file.files.pop(old)
        new_cabs.append(new)
    info['cabs']=new_cabs
    return info

manifest={}
# string tables
src=os.path.join(SW,'localization-string-tables-english(en)_assets_all.bundle')
dst=os.path.join(OUT,'localization-string-tables-italian(it)_assets_all.bundle')
env=UnityPy.load(src)
c=0
for obj in env.objects:
    if obj.type.name!='MonoBehaviour': continue
    tt=obj.read_typetree(); name=tt.get('m_Name','')
    if name.endswith('_en'):
        col=name[:-3]; vals=it[col]
        if len(vals)!=len(tt['m_TableData']): raise SystemExit('len '+col)
        tt['m_LocaleId']['m_Code']='it'; tt['m_Name']=col+'_it'
        for ent,val in zip(tt['m_TableData'],vals): ent['m_Localized']=val
        obj.save_typetree(tt); c+=1
manifest['string']=unique_names(env,'string')
open(dst,'wb').write(env.file.save(packer='lz4'))
print('string tables',c)

# asset table
src=os.path.join(SW,'localization-asset-tables-english(en)_assets_all.bundle')
dst2=os.path.join(OUT,'localization-asset-tables-italian(it)_assets_all.bundle')
env=UnityPy.load(src); c=0
for obj in env.objects:
    if obj.type.name!='MonoBehaviour': continue
    tt=obj.read_typetree()
    if tt.get('m_Name','').endswith('_en'):
        tt['m_LocaleId']['m_Code']='it'; tt['m_Name']='AssetTable_it'; obj.save_typetree(tt); c+=1
manifest['assettable']=unique_names(env,'assettable')
open(dst2,'wb').write(env.file.save(packer='lz4'))
print('asset tables',c)

# locales
src=os.path.join(SW,'localization-locales_assets_all.bundle')
dst3=os.path.join(OUT,'localization-locales-italian(it)_assets_all.bundle')
env=UnityPy.load(src); c=0
for obj in env.objects:
    if obj.type.name!='MonoBehaviour': continue
    tt=obj.read_typetree()
    if tt.get('m_Name','')=='English (en)':
        tt['m_Name']='Italian (it)'; tt['m_Identifier']['m_Code']='it'; tt['m_LocaleName']='Italiano (it)'; tt['m_SortOrder']=9999
        obj.save_typetree(tt); c+=1
manifest['locales']=unique_names(env,'locales')
open(dst3,'wb').write(env.file.save(packer='lz4'))
print('locales',c)

json.dump(manifest,open(os.path.join(OUT,'manifest.json'),'w'))
for k,v in manifest.items(): print(k,v)
for p in (dst,dst2,dst3):
    print(os.path.basename(p),hashlib.md5(open(p,'rb').read()).hexdigest(),os.path.getsize(p))
