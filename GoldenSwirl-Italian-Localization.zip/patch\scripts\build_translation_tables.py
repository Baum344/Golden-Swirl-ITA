import json, os, re
from collections import Counter

BASE=r'C:\Users\baum3\AppData\Local\Temp\opencode\gs'
IT=os.path.join(BASE,'it')
corpus=json.load(open(os.path.join(BASE,'corpus.json'),encoding='utf-8'))
order=list(corpus.keys())
files={0:'00_BuffTable.txt',2:'02_CardTable.txt',3:'03_IntroSubtitleTable.txt',4:'04_RelicTable.txt',
5:'05_MessageBoxTable.txt',6:'06_CharacterTable.txt',7:'07_ModifierTable.txt',8:'08_UnlockContentTable.txt',
9:'09_AscensionEffectTable.txt',10:'10_ShopTable.txt',11:'11_SwirlEffectTable.txt',12:'12_CommonStringTable.txt',
13:'13_ZoneBuffEffectTable.txt',14:'14_CardTagTable.txt',15:'15_SkillTreeTable.txt',16:'16_Popup.txt',
17:'17_EquipmentTable.txt',18:'18_CurrencyTable.txt'}
def readlines(fn):
    t=open(os.path.join(IT,fn),encoding='utf-8').read().replace('\r\n','\n')
    ls=t.split('\n')
    if ls and ls[-1]=='': ls=ls[:-1]
    return ls
PH={'Event Title':'Titolo Evento','Event Text':'Testo Evento','Testing Dialog':'Dialogo di Test',
    'Testing Modifier':'Modificatore di Test','Test Card Modifier Reward':'Ricompensa Modificatore Carta di Test','':''}
reals=[]
for n in range(1,9): reals+=readlines(f'ev_real_{n}.txt')
def post(en,it):
    if '\n' in en: it=it.replace('\\n','\n')
    if '\r' in en: it=it.replace('\\r','\r')
    if '\t' in en: it=it.replace('\\t','\t')
    return it
ri=0; tables={}
for idx,col in enumerate(order):
    entries=corpus[col]; out=[]
    if col=='Event Table':
        for e in entries:
            it=PH[e['en']] if e['en'] in PH else reals[ri]
            if e['en'] not in PH: ri+=1
            out.append({'id':str(e['id']),'key':e['key'],'en':e['en'],'it':post(e['en'],it)})
    else:
        ls=readlines(files[idx]); assert len(ls)==len(entries),(col,)
        for i,e in enumerate(entries):
            out.append({'id':str(e['id']),'key':e['key'],'en':e['en'],'it':post(e['en'],ls[i])})
    tables[col]=out

# ---- corrections ----
CORR={
 ('Buff Table','8264191303680'): "Aumenta di {stack} i danni d'attacco delle carte {cardColor:Red.colorNameColored}/{cardColor:Blue.colorNameColored}/{cardColor:Yellow.colorNameColored}.",
 ('Event Table','219325689125175296'): "\"La vestirò <wiggle><color={color.pink}>lei</color></wiggle> di <wiggle><color={color.pink}>seta nera</color></wiggle>, le incatenerò il collo con il <wiggle><color={color.pink}>ferro</color></wiggle>, e con la sua santa <wiggle><color={color.pink}>lingua</color></wiggle> profanata, bacerò la mia carne e la mia anima centimetro dopo centimetro. \"Lecca la punta del dito, come se toccasse la Fanciulla dell'Alba.",
 ('Event Table','219333094781255680'): "\"Li ho visti... i <wave><color={color.yellow}>sei angeli alati</color></wave>, nascosti tra luce e ombra. Sono venuti a <wave><color={color.yellow}>giudicarci</color></wave>... o a <wave><color={color.yellow}>negoziare</color></wave>?\" Lorenzo fissò il vortice.",
 ('Event Table','219608254172135424'): "\"Ora, <wave><color={color.yellow}>esse</color></wave> appartengono solo a <wave><color={color.yellow}>me</color></wave>. Toccale, viaggiatore, e assaporeranno prima il tuo sangue... poi ti faranno sapere cosa significa davvero perdere.\" Ti sollevò il mento.",
 ('Event Table','220051844245520384'): "\"Io... non vedo più uno <shake><color={color.purple}>sfidante</color></shake>, solo un perfetto e <shake><color={color.purple}>sacro</color></shake> <shake><color={color.purple}>guscio</color></shake>.\"",
}
sc='Sblocca nuove {cards:plural:{keyword.card.ToString.ToLower}|{keyword.card.ToString.ToLower}|{keyword.cards.ToString.ToLower}} ottenibili in eventi e negozi:'+chr(10)+'{isLinksHighlighted:list:- {:choose(True|False):<mark={color.highlightedLink}>|}{cards.index:card()}{:choose(True|False):</mark>|}|'+r'\n}'
sr='Sblocca nuove {relics:plural:{keyword.relic.ToString.ToLower}|{keyword.relic.ToString.ToLower}|{keyword.relics.ToString.ToLower}} ottenibili in eventi e negozi:'+chr(10)+'{isLinksHighlighted:list:- {:choose(True|False):<mark={color.highlightedLink}>|}{relics.index:relic()}{:choose(True|False):</mark>|}|'+r'\n}'
CORR[('SkillTreeTable','1013315366912')]=sc
CORR[('SkillTreeTable','16003632033792')]=sr
for col,es in tables.items():
    for e in es:
        if (col,e['id']) in CORR:
            e['it']=CORR[(col,e['id'])]
print('Event reals consumed',ri,'of',len(reals))
json.dump(tables, open(os.path.join(BASE,'it_final.json'),'w',encoding='utf-8'), ensure_ascii=False, indent=1)
json.dump({col:[x['it'] for x in v] for col,v in tables.items()}, open(os.path.join(BASE,'it_ordered.json'),'w',encoding='utf-8'), ensure_ascii=False)

def extract(s):
    toks=[];i=0
    while i<len(s):
        c=s[i]
        if c=='{':
            d=0;j=i
            while j<len(s):
                if s[j]=='{':d+=1
                elif s[j]=='}':
                    d-=1
                    if d==0:break
                j+=1
            toks.append(s[i:j+1]);i=j+1;continue
        if c=='<':
            j=s.find('>',i)
            if j!=-1:toks.append(s[i:j+1]);i=j+1;continue
        if c=='%' and i+1<len(s):
            m=re.match(r'%[0-9]*[sdf]',s[i:])
            if m:toks.append(m.group(0));i+=len(m.group(0));continue
        if c=='\\' and i+1<len(s) and s[i+1] in 'nrt\\':
            toks.append(s[i:i+2]);i+=2;continue
        i+=1
    return toks
bad=[]
for col,es in tables.items():
    for e in es:
        te=extract(e['en']);ti=extract(e['it'])
        if Counter(te)!=Counter(ti):
            bad.append({'col':col,'key':e['key'],'missing':dict(Counter(te)-Counter(ti)),'extra':dict(Counter(ti)-Counter(te))})
print('TOKEN MISMATCHES:',len(bad))
for b in bad: print(b)
