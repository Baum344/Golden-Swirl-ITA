# verify.ps1 - Verifica l'integrita' dei file installati confrontando gli SHA-256.
param(
    [string]$GameDir = ""
)
$ErrorActionPreference = "Stop"
$Overlay = Join-Path $PSScriptRoot "patch\overlay"
$Manifest = Join-Path $PSScriptRoot "patch\overlay.sha256"

if (-not $GameDir) { $GameDir = Split-Path $PSScriptRoot -Parent }

$ok = 0; $bad = 0
Get-Content -LiteralPath $Manifest | ForEach-Object {
    if ($_ -match '^([0-9a-fA-F]{64})\s+(.+)$') {
        $expected = $matches[1].ToLower()
        $rel = $matches[2]
        $target = Join-Path $GameDir ($rel -replace '/', '\')
        if (Test-Path -LiteralPath $target) {
            $actual = (Get-FileHash -Algorithm SHA256 -LiteralPath $target).Hash.ToLower()
            if ($actual -eq $expected) { Write-Host "OK   $rel" -ForegroundColor Green; $ok++ }
            else { Write-Host "DIFF $rel" -ForegroundColor Red; $bad++ }
        } else {
            Write-Host "MANCA $rel" -ForegroundColor Yellow; $bad++
        }
    }
}
Write-Host ""
Write-Host "Verifica completata: $ok ok, $bad problemi."
